#include "Adafruit_mfGFX.h"

// This file is intentionally left blank, so that the header class can be
// statically configured from the Arduino project using #define statements.
// This is done in order to provide a wide variety of font options, while
// loading only the ones that will be used by a project (preserving flash
// space).